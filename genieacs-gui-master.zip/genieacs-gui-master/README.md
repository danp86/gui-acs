genieacs-gui
============

A GUI front end for GenieACS built with Ruby on Rails.
